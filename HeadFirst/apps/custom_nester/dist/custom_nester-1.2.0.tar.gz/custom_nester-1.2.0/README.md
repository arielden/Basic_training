custom_nester
=======

What is this?
--------------

This is a module created basically for test and learning purposes.

custom_nester.py module, provides the function called
print_lol() which prints lists that may or may not include nested lists.
the funtions needs one requiered argunment (the list) and one optional (number of tabs to indent de printed result)


Requirements
------------

* python >= 3.9


Credits
------------

Ariel Denaro

