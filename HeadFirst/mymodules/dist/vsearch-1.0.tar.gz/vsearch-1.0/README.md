custom_vsearch
====================

What is this?
--------------

This is a module created basically for test and learning purposes.

    search4letters function takes a positional argument called 'phrase', which is any given string
    and an optional argument called 'letters' (by default 'aeiou').
    The function search the letters in the given phrase and returns a set with the found elements.
    
    ---Arguments----------(default value)
    1st - 'phrase'
    2nd - 'letters' ('aeiou')



Requirements
------------

* python >= 3.9


Credits
------------

Ariel Denaro